# Design System Strategy: ERP Document Transfer

## 1. Overview & Creative North Star
**Creative North Star: The Sovereign Ledger**

This design system moves away from the "cluttered utility" of traditional ERPs toward a high-density editorial experience that prioritizes data sovereignty and logical momentum. It treats financial document transfer not as a series of inputs, but as a prestigious narrative flow. 

The system breaks the "template" look by utilizing **intentional asymmetry**—offsetting metadata columns against core financial figures—and **layered transparency**. By replacing rigid 1px dividers with tonal shifts, we create a UI that feels desktop-native (PyQt5) but possesses the sophistication of a high-end financial broadsheet. The interface should feel like an expensive tool: weighted, precise, and authoritative.

---

## 2. Colors & Surface Philosophy
The palette is rooted in a professional, neutral enterprise foundation, punctuated by deep authoritative blues (`primary: #0037b0`).

### The "No-Line" Rule
To achieve a premium feel, **1px solid borders are strictly prohibited for sectioning.** Boundaries between document headers, line items, and transfer settings must be defined solely through background color shifts. 
- Use `surface-container-low` (#f2f4f6) for the main dialog background.
- Use `surface-container-highest` (#e0e3e5) for secondary sidebars or sticky headers.
- Use `surface-container-lowest` (#ffffff) for the active data entry area to provide immediate focus.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of stacked fine paper.
- **Base Level:** `background` (#f7f9fb)
- **Primary Dialog Layer:** `surface-container-low` (#f2f4f6)
- **Data Cards / Financial Modules:** `surface-container-lowest` (#ffffff)
- **Interactive Toggles / Draft States:** `surface-container-high` (#e6e8ea)

### The "Glass & Gradient" Rule
For conversion progress or floating action bars, use a backdrop-blur effect (12px–20px blur) with a semi-transparent `surface` color. For the main "Transfer/Convert" CTA, apply a subtle linear gradient from `primary` (#0037b0) to `primary_container` (#1d4ed8) at a 135° angle. This adds "soul" and depth that prevents the ERP from feeling like a legacy spreadsheet.

---

## 3. Typography
We utilize a dual-font system to balance editorial elegance with dense data readability.

*   **Display & Headlines (Manrope):** Used for document titles and high-level totals (e.g., "Invoice Transfer: #FAC-2023"). The geometric nature of Manrope conveys modern authority.
*   **Body & Labels (Inter):** Used for all financial data and form inputs. Inter’s high x-height ensures clarity in high-density PyQt5 layouts.

**Brand Identity through Hierarchy:**
- **Financial Boldness:** All monetary values should use `title-md` or `headline-sm` in `on_surface` (#191c1e) with a slightly tighter letter-spacing (-0.02em) to feel "heavy" and secure.
- **Metadata Subtlety:** Use `label-sm` in `on_surface_variant` (#434655) for captions like "VAT ID" or "Conversion Date," ensuring they don't compete with the core document numbers.

---

## 4. Elevation & Depth
In this system, depth is a function of **Tonal Layering**, not structural shadows.

*   **The Layering Principle:** Place a white (`surface-container-lowest`) document card on top of a light grey (`surface-container-low`) staging area. The 0.2rem contrast creates a natural lift.
*   **Ambient Shadows:** For floating dialogs or tooltips, use a "Cloud Shadow": `box-shadow: 0 12px 32px rgba(25, 28, 30, 0.06)`. Note the extremely low 6% opacity; it should be felt, not seen.
*   **The "Ghost Border" Fallback:** If a divider is mandatory for legal clarity in financial rows, use `outline-variant` (#c4c5d7) at **15% opacity**. Never use 100% opaque lines.
*   **Glassmorphism:** Use for "Status Overlays" (e.g., "Processing..."). A `surface_variant` color at 80% opacity with a `blur(10px)` allows the document data to remain visible underneath, maintaining the user's spatial context.

---

## 5. Components

### Buttons
- **Primary (Conversion):** `primary` background, `on_primary` text. `md` (0.375rem) corners. Use the "Glass & Gradient" rule.
- **Secondary (Cancel/Back):** `secondary_container` background with `on_secondary_container` text. No border.
- **Tertiary (Auxiliary Actions):** Transparent background, `primary` text. Underline only on hover.

### High-Density Data Inputs
- **Text Inputs:** Use `surface-container-lowest` for the field. The focus state is indicated by a 2px bottom-bar of `primary` (#0037b0), not a full-perimeter stroke.
- **Financial List Items:** Instead of dividers, use a `2.5` (0.5rem) spacing gap. On hover, change the background to `surface-container-low`.

### Document Status Chips
- **Success/Verified:** `tertiary_fixed` background with `on_tertiary_fixed_variant` text.
- **Error/Discrepancy:** `error_container` background with `on_error_container` text.

### The "Transfer Bridge" (Custom Component)
A central visual element showing the "Source Document" (left) and "Target Document" (right) with an arrow utilizing a `surface_tint` (#2151da) gradient. This creates a logical flow for the conversion process.

---

## 6. Do's and Don'ts

### Do
- **Do** use `10` (2.25rem) or `12` (2.75rem) spacing for major section gutters to allow the data to breathe.
- **Do** align currency symbols to the left and figures to the right in table cells for professional financial alignment.
- **Do** use `sm` (0.125rem) roundedness for small elements like checkboxes, but `md` (0.375rem) for main buttons and cards.

### Don'ts
- **Don't** use pure black (#000000) for text. Use `on_surface` (#191c1e) to keep the editorial feel soft.
- **Don't** use standard 1px borders to separate line items. Use a subtle alternate-row background color (`surface_container_low`).
- **Don't** use high-contrast shadows. If the shadow is clearly visible, it is too dark. Aim for "Ambient Light" logic.